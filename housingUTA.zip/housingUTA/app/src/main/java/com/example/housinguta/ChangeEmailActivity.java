package com.example.housinguta;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.util.Patterns;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthCredential;
import com.google.firebase.auth.EmailAuthProvider;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.Objects;

public class ChangeEmailActivity extends AppCompatActivity {

    FirebaseUser currentUser;
    Button btnMainMenu,btnUpdateEmail,btnAuthenticate;
    Boolean authenticated;
    String email;
    String firstname,lastname,isAdmin;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_change_email);

        currentUser = FirebaseAuth.getInstance().getCurrentUser();
        authenticated=false;
        btnMainMenu=findViewById(R.id.btnHomeMenu);
        btnMainMenu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                switchToHome();
            }
        });

        btnAuthenticate = findViewById(R.id.btnauthenticate);
        btnAuthenticate.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view) {
                authenticateUser();
            }
        });

        btnUpdateEmail = findViewById(R.id.btnUpdate);
        btnUpdateEmail.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view) {
                changeEmail();
            }
        });

        FirebaseDatabase database = FirebaseDatabase.getInstance();
        DatabaseReference reference = database.getReference("users").child(currentUser.getUid());
        reference.addValueEventListener(new ValueEventListener()
        {
            @SuppressLint("SetTextI18n")//this is what was changed!!!!!
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot)
            {
                User user = snapshot.getValue(User.class);
                if (user != null) {
                    firstname=(user.firstName);
                    lastname=(user.lastName);
                    isAdmin=(user.isAdmin);
                }
            }
            @Override
            public void onCancelled(@NonNull DatabaseError error)
            {
            }
        });
    }

    private void authenticateUser() {
        EditText etLoginEmail = findViewById(R.id.etEmail);
        EditText etLoginPassword = findViewById(R.id.etPassword);

        email = etLoginEmail.getText().toString();
        String password = etLoginPassword.getText().toString();

        //checks if the fields are empty
        if (email.isEmpty() || password.isEmpty()) {
            Toast.makeText(this, "Please fill all fields", Toast.LENGTH_LONG).show();
            return;
        }
        //checks if the email is in the right format
        if (!Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            Toast.makeText(this, "Please enter a valid email", Toast.LENGTH_LONG).show();
            return;
        }
        //checks if the password is at least 6 chars long
        if (password.length() < 6) {
            Toast.makeText(this, "Please enter a longer password", Toast.LENGTH_LONG).show();
            return;
        }

        //user = FirebaseAuth.getInstance().getCurrentUser();
        // Get auth credentials from the user for re-authentication. The example below shows
        // email and password credentials but there are multiple possible providers,
        // such as GoogleAuthProvider or FacebookAuthProvider.
        AuthCredential credential = EmailAuthProvider
                .getCredential(email, password);

        // Prompt the user to re-provide their sign-in credentials
        currentUser.reauthenticate(credential)
                .addOnCompleteListener(new OnCompleteListener<Void>() {
                    @Override
                    public void onComplete(@NonNull Task<Void> task) {
                        Toast.makeText(ChangeEmailActivity.this,"enter new email",Toast.LENGTH_SHORT).show();
                        authenticated=true;
                    }
                });
    }
    private void changeEmail() {
        EditText etNEWemail = findViewById(R.id.etFirstname);
        String newEmail = etNEWemail.getText().toString().trim();

        EditText etconfirmNEWemail = findViewById(R.id.etLastname);
        String confirmNewEmail = etconfirmNEWemail.getText().toString().trim();

        //System.out.println("email"+newEmail +" and "+confirmNewEmail);

        //checks if the user has authenticated their account first
        if(!authenticated)
        {
            Toast.makeText(this, "Please authenticate first", Toast.LENGTH_LONG).show();
            return;
        }
        //check if they are empty
        if (newEmail.isEmpty() || confirmNewEmail.isEmpty()) {
            Toast.makeText(this, "Please fill all fields", Toast.LENGTH_LONG).show();
            return;
        }
        //checks if the email is in the right format
        if (!Patterns.EMAIL_ADDRESS.matcher(newEmail).matches())
        {
            Toast.makeText(this, "Please enter a valid email", Toast.LENGTH_LONG).show();
            return;
        }
        //checks if the current doesn't equal to new
        if (email.equals(newEmail)) {
            Toast.makeText(this, "This is your current email", Toast.LENGTH_LONG).show();
            return;
        }
        //check if they are the same
        if(!newEmail.equals(confirmNewEmail)) {
            Toast.makeText(this, "Emails are not equal", Toast.LENGTH_LONG).show();
            return;
        }

        currentUser.updateEmail(newEmail)
                .addOnCompleteListener(new OnCompleteListener<Void>() {
                    @Override
                    public void onComplete(@NonNull Task<Void> task) {
                        if (task.isSuccessful()) {
                            User user = new User(firstname, lastname, newEmail, isAdmin);
                            FirebaseDatabase.getInstance().getReference("users")
                                    .child(Objects.requireNonNull(FirebaseAuth.getInstance().getCurrentUser()).getUid())
                                    .setValue(user).addOnCompleteListener(new OnCompleteListener<Void>() {
                                        @Override
                                        public void onComplete(@NonNull Task<Void> task) {
                                            Toast.makeText(ChangeEmailActivity.this, "email changed!", Toast.LENGTH_LONG).show();
                                            //if 0 then user is not admin
                                            if (isAdmin.equals("0")) {
                                                switchToAccountInfo();
                                            }
                                            //else user is admin
                                            else {
                                                switchToAdminHome();
                                            }
                                        }
                                    });
                        }
                    }
                });
    }
    private void switchToAccountInfo()
    {
        Intent intent = new Intent(this, AccountInfoActivity.class);
        startActivity(intent);
        finish();
    }
    private void switchToAdminHome()
    {
        Intent intent = new Intent(this, AdminHomeActivity.class);
        startActivity(intent);
        finish();
    }
    private void switchToHome()
    {
        if(isAdmin.equals("0"))
        {

            Intent intent = new Intent(this, HomeMenu.class);
            startActivity(intent);
            finish();
        }
        else {
            Intent intent = new Intent(this, AdminAccountInfoActivity.class);
            startActivity(intent);
            finish();
        }
    }
}