package com.example.housinguta;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

public class AccountInfoFragment extends Fragment
{
    View view;
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState)
    {

        view=inflater.inflate(R.layout.fragment_account_info,container,false);

        TextView account_info = view.findViewById(R.id.account_info);
        account_info.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view) {
                //Toast.makeText(getActivity(), "viewing account info", Toast.LENGTH_LONG).show();
                Intent intent = new Intent(view.getContext(), AccountInfoActivity.class);
                view.getContext().startActivity(intent);
            }
        });

        TextView change_names = view.findViewById(R.id.change_names);
        change_names.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view) {
                //Toast.makeText(getActivity(), "changing names", Toast.LENGTH_LONG).show();
                Intent intent = new Intent(view.getContext(), ChangeNamesActivity.class);
                view.getContext().startActivity(intent);
            }
        });
        TextView change_email = view.findViewById(R.id.change_email);
        change_email.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view)
            {
                //Toast.makeText(getActivity(), "changing email", Toast.LENGTH_LONG).show();
                Intent intent = new Intent(view.getContext(), ChangeEmailActivity.class);
                view.getContext().startActivity(intent);
            }
        });
        TextView change_password = view.findViewById(R.id.change_password);
        change_password.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view)
            {
                //Toast.makeText(getActivity(), "changing password", Toast.LENGTH_LONG).show();
                Intent intent = new Intent(view.getContext(), ChangePasswordActivity.class);
                view.getContext().startActivity(intent);
            }
        });
        return view;
    }
}
