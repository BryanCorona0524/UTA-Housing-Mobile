package com.example.housinguta;

import androidx.annotation.ColorRes;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.net.Uri;

public class GenAptmActivity extends AppCompatActivity {
    TextView rPerAptmTv;
    TextView rPerBedTv;
    TextView phoneTv;
    TextView addressTv;
    TextView aptmTv;
    ImageView housingImage;
    TextView model;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_gen_aptm);
        rPerAptmTv = findViewById(R.id.rentPerApartment);
        rPerBedTv = findViewById(R.id.rentPerBedroom);
        phoneTv = findViewById(R.id.PhoneTv);
        addressTv = findViewById(R.id.AddressTv);
        aptmTv = findViewById(R.id.appartmentNameText);
        housingImage = findViewById(R.id.housingImage);
        model = findViewById(R.id.modelText);

        rPerAptmTv.append(getIntent().getStringExtra("price1"));
        rPerBedTv.append(getIntent().getStringExtra("price2"));
        phoneTv.append(getIntent().getStringExtra("phone"));
        addressTv.append(getIntent().getStringExtra("address"));
        aptmTv.append(getIntent().getStringExtra("housing"));
        if(getIntent().getStringExtra("housing").equals("Centennial Court")){
            model.append("N/A");
        }
        Bitmap bitmap = BitmapFactory.decodeByteArray(
                getIntent().getByteArrayExtra("byteArray"), 0,
                    getIntent().getByteArrayExtra("byteArray").length);
        housingImage.setImageBitmap(bitmap);
    }
    public void gotoLink(View v) {
        if(getIntent().getStringExtra("housing").equals("Centennial Court")) {return;}

        Uri uri = Uri.parse(getIntent().getStringExtra("model"));
        Intent intent = new Intent(Intent.ACTION_VIEW, uri);
        startActivity(intent);

    }
    public void gotoList(View v){
        Intent intent = new Intent(this,OnCampusHousing.class);
        startActivity(intent);
    }


}