package com.example.housinguta;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.util.List;

public class ApartmentAdapter extends ArrayAdapter<Apartment>
{

    public ApartmentAdapter(Context context, int resource, List<Apartment> apartmentList)
    {
        super(context,resource,apartmentList);
    }


    @Override
    public View getView(int position, View convertView, ViewGroup parent)
    {
        Apartment apartment = getItem(position);

        if(convertView == null)
        {
            convertView = LayoutInflater.from(getContext()).inflate(R.layout.apartment_cell, parent, false);
        }
        TextView nameTv  = convertView.findViewById(R.id.apartmentName);
        TextView addTv   = convertView.findViewById(R.id.addressText);
        TextView priceTv = convertView.findViewById(R.id.priceText);

        nameTv.setText(apartment.getName());
        addTv.setText(apartment.getAddress());
        priceTv.setText(apartment.getPrice());
        if(apartment.getPrice().contains("n/a"))
            priceTv.setVisibility(View.GONE);
        else
            priceTv.setVisibility(View.VISIBLE);

        return convertView;
    }
}