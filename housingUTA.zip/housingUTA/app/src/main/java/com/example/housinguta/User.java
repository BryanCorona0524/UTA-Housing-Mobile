package com.example.housinguta;

public class User {
    public String firstName;
    public String lastName;
    public String email;
    public String isAdmin;

    public User()
    {
    }

    public User (String firstName, String lastName, String email, String isAdmin) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.email = email;
        this.isAdmin=isAdmin;
    }
}
