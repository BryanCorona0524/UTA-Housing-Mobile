package com.example.housinguta;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

public class MainMenuFragment extends Fragment
{
    View view;
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState)
    {

        view=inflater.inflate(R.layout.fragment_mainmenu,container,false);

        Button btnOnCampusHousing = view.findViewById(R.id.btnResidenceExplore);
        btnOnCampusHousing.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view)
            {
                Intent intent = new Intent(view.getContext(), OnCampusHousing.class);
                view.getContext().startActivity(intent);
            }
        });

        Button btnOnCampusApply = view.findViewById(R.id.btnOnCampusApply);
        btnOnCampusApply.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view)
            {
                Intent intent = new Intent(view.getContext(), OCApplicationActivity.class);
                view.getContext().startActivity(intent);
            }
        });
        Button btnOffCampusHousing = view.findViewById(R.id.btnOffCampusHousing);
        btnOffCampusHousing.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view)
            {
                Intent intent = new Intent(view.getContext(), OffCampusMain.class);
                view.getContext().startActivity(intent);
            }
        });
        return view;
    }
}
