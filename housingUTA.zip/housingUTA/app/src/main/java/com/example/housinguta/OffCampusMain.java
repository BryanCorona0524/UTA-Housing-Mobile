package com.example.housinguta;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.SearchView;

import java.util.ArrayList;
import java.util.Collections;

public class OffCampusMain extends AppCompatActivity implements AdapterView.OnItemClickListener {

    public ArrayList<Apartment> apartmentList  = new ArrayList<>();
    public String[] aptData = {
        "101 Center>campus>101 S. Center St., Arlington, TX 76010>101center.com>18174776431>101center@greystar.com>$699 - $1,399>1",
        "Campus Edge on UTA Boulevard>campus>1001 UTA Boulevard, Arlington, TX 76013>americancampus.com/student-apartments/tx/arlington/campus-edge-on-uta-boulevard>18179871661>CampusEdgeonUTABlvd@americancampus.com>$854 - $914>2",
        "Centennial Court>campus>700 West Mitchell Circle, Arlington, TX 76013>campuslivingvillages.com/united-states/university-of-texas-at-arlington/centennial-court-uta-housing>18174220592>info@centennialcourtUTA.com>$504 - $1,085>3",
        "LIV+>campus>1001 S. Center St. , Arlington, TX 76010>livplusarlington.com>18174978282>n/a>$620 - $1,325>4",
        "Maverick Place>campus>930 Benge Drive, Arlington, TX 76013>maverickplace.com>18179837890>n/a>$525 - $1,050>5",
        "Midtown Urban Student Living>campus>1121 UTA Blvd., Arlington, TX 76013>liveatmidtownarlington.com>18172754700>n/a>$629 - $819>6",
        "Park Place at Arlington>campus>435 Spaniolo Drive, Arlington, TX 76010>parkplaceatarlington.com>16822824100>leasing@parkplaceatarlington.com>$699+>7",
        "The Arlie>campus>815 West Abram Street, Arlington, TX 76013>americancampus.com/student-apartments/tx/arlington/the-arlie>18177952300>thearlie@americancampus.com>$519 - $1,399>8",
        "Vintage Pads>campus>212 S. Cooper Street, Arlington, TX 76013>180apt.com/communities/vintagepads>18178033145>utaproperties.mgr@180apt.com>$750 - $1,300>9",
        "Zen Apartments>campus>805 S. Center Street, Arlington, TX 76010>180apt.com/communities/zen>18177611878>utaproperties.mgr@180apt.com>$630 - $1,300>10",
        "Amp at the Grid>north>765 Polk Drive, Arlington, TX 76011>theampatthegrid.com>18172779100>n/a>$840 - $1,480>11",
        "Alcove Oaks Apartment Homes>north>500 Tish Circle, Arlington, TX 76006>liveatalcoveoaks.com>18176637358>n/a>$885 - $1,475>12",
        "Arlington Commons>north>425 E Lamar Blvd, Arlington, TX 76011>thearlingtoncommons.com>18175836732>n/a>$885 - $1,475>13",
        "Biltmore Apartments>north>2300 Misty Ridge Circle, Arlington, TX 76011>liveatthebiltmore.com>18554602550>thebiltmoreleasing@legacyreigroup.com>$1,004+>14",
        "Element Apartments>north>1516 Arbor Town Circle, Arlington, TX 76011>livingatelement.com>14692406366>n/a>$860 - $1,450>15",
        "Enclave at Arlington>north>1249 Enclave Circle, Arlington, TX 76011>enclaveapartmentsdallas.com>18666227707>n/a>$834 - $1,568>16",
        "Flintridge Apartment Homes>north>708 Woodard Way, Arlington, TX 76011>flintridgeapartments.com>18664794194>n/a>$858 - $1,366>17",
        "The Dalton>north>1705 Big Sur Drive, Arlington, TX 76006>apartments.com/the-dalton-arlington-tx/qvbkewy>n/a>n/a>$1,150 - $1,675>18",
        "The Madrid>north>2711 Trinity Bend Circle, Arlington, TX 76006>liveatmadrid.com>18174978630>n/a>$873 - $1,082>19",
        "The Mark at 2600>north>2624 Southern Hills Blvd., Arlington, TX 76006>themark2600.com>18179685360>n/a>$790 - $1,499>20",
        "Arbrook Park>south>1401 Nandina Drive, Arlington, TX 76014>hgliving.com/apartments/tx/arlington/arbrook-park>18174823274>n/a>$990 - $2,217>21",
        "Rio on the Parkway>south>504 Dudley Circle, Arlington, TX 76010>zumper.com/apartment-buildings/p128947/rio-on-the-parkway-arlington-tx>n/a>n/a>$710 - $1,000>22",
        "Springfield Crossing>south>1801 West Arkansas Lane, Arlington, TX 76013>myspringfieldcrossing.com>18174613354>n/a>n/a>23",
        "The Franciscan>south>3006 Franciscan Drive, Arlington, TX 76015>franciscanofarlington.com>18175223777>n/a>$927 - $1,884>24",
        "Hendrix Apartments>east>3020 E Park Row, Arlington, TX 76010>liveathendrixapartments.com>18883988651>hendrixleasing@legacyreigroup.com>$1,004+>25",
        "The Destino>east>2815 Osler Drive , Grand Prairie, TX 75051>thedestinoapts.com>19729881200>n/a>$1,050 - $1,470>26",
        "The Woodlands>west>2800 Lynnwood Drive, Arlington, TX 76013>thewoodlandsarlington.com>18174618271>n/a>n/a>27",
        "Venue at 8651>west>8651 Meadowbrook Boulevard, Fort Worth, TX 76120>livebh.com/apartments/venue-at-8651>18176312147>n/a>$774 - $1,915>28"
    };

    boolean filterHidden = true;
    boolean filtersActive[] = { true,false,false,false,false,false };

    private ListView listView;
    private LinearLayout filterView1;
    private LinearLayout filterView2;

    private Button backButton, regionButton;
    private Button campusButton, northButton, southButton, westButton, eastButton, allButton;

    private ArrayList<String> selectedFilters = new ArrayList<String>();
    private String currentSearchText = "";
    private SearchView searchView;

    private int white, darkGray, black;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ocmain);

        initSearchWidgets();
        initWidgets();
        setupData();
        setUpList();
        hideFilter();
        initColors();
        lookSelected(allButton);
        selectedFilters.add("all");
        allFilter();

        setAdapter(apartmentList);
        listView.setOnItemClickListener(this);
    }

    public void onItemClick(AdapterView<?> adapterView, View view, int position, long l)
    {
        Apartment selectApartment = (Apartment) (listView.getItemAtPosition(position));
        Intent intent;
        intent = new Intent(this, Profile.class);

        intent.putExtra("name", selectApartment.getName());
        intent.putExtra("price", selectApartment.getPrice());
        intent.putExtra("address", selectApartment.getAddress());
        intent.putExtra("website", selectApartment.getWebsite());
        intent.putExtra("phone", selectApartment.getPhone());
        intent.putExtra("email", selectApartment.getEmail());
        intent.putExtra("image", selectApartment.getImage());

        hideFilter();
        startActivity(intent);
    }

    private void initColors()
    {
        white = ContextCompat.getColor(getApplicationContext(), R.color.white);
        black = ContextCompat.getColor(getApplicationContext(), R.color.black);
        darkGray = ContextCompat.getColor(getApplicationContext(), R.color.grey);
    }

    private void unSelectAllFilterButtons()
    {
        lookUnSelected(allButton);
        lookUnSelected(campusButton);
        lookUnSelected(northButton);
        lookUnSelected(southButton);
        lookUnSelected(westButton);
        lookUnSelected(eastButton);

        for(int i = 0; i < 6; i++)
            filtersActive[i] = false;
    }

    private void lookSelected(Button parsedButton)
    {
        parsedButton.setTextColor(white);
        parsedButton.setBackgroundColor(black);
    }

    private void lookUnSelected(Button parsedButton)
    {
        parsedButton.setTextColor(black);
        parsedButton.setBackgroundColor(darkGray);
    }

    private void initWidgets()
    {
        backButton   = findViewById(R.id.backButton);
        regionButton = findViewById(R.id.showRegions);
        filterView1  = findViewById(R.id.filterTabsLayout1);
        filterView2  = findViewById(R.id.filterTabsLayout2);

        campusButton = findViewById(R.id.campusAreaFilter);
        northButton  = findViewById(R.id.northFilter);
        southButton  = findViewById(R.id.southFilter);
        westButton   = findViewById(R.id.westFilter);
        eastButton   = findViewById(R.id.eastFilter);
        allButton    = findViewById(R.id.allFilter);
    }

    private void addAptFromString(String str)
    {
        String[] arr = str.split(">");
        Apartment apt = new Apartment(arr);
        apartmentList.add(apt);
    }

    private void setupData()
    {
        apartmentList.clear();
        for(String line: aptData)
            addAptFromString(line);
    }

    private void initSearchWidgets()
    {
        searchView = (SearchView) findViewById(R.id.listSearchView);

        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener()
        {
            @Override
            public boolean onQueryTextSubmit(String s)
            {
                return false;
            }

            @Override
            public boolean onQueryTextChange(String s)
            {
                currentSearchText = s;
                ArrayList<Apartment> filteredApartments = new ArrayList<>();

                for(Apartment apartment: apartmentList)
                {
                    if(apartment.getName().toLowerCase().contains(s.toLowerCase()))
                    {
                        if(selectedFilters.contains("all"))
                        {
                            filteredApartments.add(apartment);
                        }
                        else
                        {
                            for(String filter: selectedFilters)
                            {
                                if (apartment.getName().toLowerCase().contains(filter))
                                {
                                    filteredApartments.add(apartment);
                                }
                            }
                        }
                    }
                }
                setAdapter(filteredApartments);

                return false;
            }
        });
    }

    private void hideFilter()
    {
        filterHidden = true;
        filterView1.setVisibility(View.GONE);
        filterView2.setVisibility(View.GONE);
    }

    private void showFilter()
    {
        filterHidden = false;
        filterView1.setVisibility(View.VISIBLE);
        filterView2.setVisibility(View.VISIBLE);
    }

    private void setUpList()
    {
        listView = (ListView) findViewById(R.id.apartmentListView);
        setAdapter(apartmentList);
    }

    private void filterList(String status, boolean append)
    {
        if(status != null)
        {
            if(append && !selectedFilters.contains(status))
                selectedFilters.add(status);
            else if(!append && selectedFilters.contains(status))
                selectedFilters.remove(status);
        }

        ArrayList<Apartment> filteredApartments = new ArrayList<>();

        for(Apartment apartment: apartmentList)
        {
            for(String filter: selectedFilters)
            {
                if(apartment.getRegion().toLowerCase().contains(filter))
                {
                    if(currentSearchText == "")
                    {
                        filteredApartments.add(apartment);
                    }
                    else
                    {
                        if(apartment.getName().toLowerCase().contains(currentSearchText.toLowerCase()))
                        {
                            filteredApartments.add(apartment);
                        }
                    }
                }
            }
        }

        setAdapter(filteredApartments);
    }

    public void allFilterTapped(View view)
    {
        allFilter();
    }

    public void allFilter()
    {
        selectedFilters.clear();
        selectedFilters.add("all");

        unSelectAllFilterButtons();
        lookSelected(allButton);
        filtersActive[0] = true;

        setAdapter(apartmentList);
    }

    public void campusFilterTapped(View view)
    {
        lookUnSelected(allButton);
        filtersActive[0] = false;

        if(filtersActive[1])
        {
            filterList("campus",false);
            lookUnSelected(campusButton);
            filtersActive[1] = false;
            if(!(filtersActive[1]||filtersActive[2]||filtersActive[3]||filtersActive[4]||filtersActive[5]))
                allFilter();
        }
        else
        {
            filterList("campus",true);
            lookSelected(campusButton);
            filtersActive[1] = true;
        }
    }

    public void northFilterTapped(View view)
    {
        lookUnSelected(allButton);
        filtersActive[0] = false;

        if(filtersActive[2])
        {
            filterList("north",false);
            lookUnSelected(northButton);
            filtersActive[2] = false;
            if(!(filtersActive[1]||filtersActive[2]||filtersActive[3]||filtersActive[4]||filtersActive[5]))
                allFilter();
        }
        else
        {
            filterList("north",true);
            lookSelected(northButton);
            filtersActive[2] = true;
        }
    }

    public void southFilterTapped(View view)
    {
        lookUnSelected(allButton);
        filtersActive[0] = false;

        if(filtersActive[3])
        {
            filterList("south",false);
            lookUnSelected(southButton);
            filtersActive[3] = false;
            if(!(filtersActive[1]||filtersActive[2]||filtersActive[3]||filtersActive[4]||filtersActive[5]))
                allFilter();
        }
        else
        {
            filterList("south",true);
            lookSelected(southButton);
            filtersActive[3] = true;
        }
    }

    public void westFilterTapped(View view)
    {
        lookUnSelected(allButton);
        filtersActive[0] = false;

        if(filtersActive[4])
        {
            filterList("west",false);
            lookUnSelected(westButton);
            filtersActive[4] = false;
            if(!(filtersActive[1]||filtersActive[2]||filtersActive[3]||filtersActive[4]||filtersActive[5]))
                allFilter();
        }
        else
        {
            filterList("west",true);
            lookSelected(westButton);
            filtersActive[4] = true;
        }
    }

    public void eastFilterTapped(View view)
    {
        lookUnSelected(allButton);
        filtersActive[0] = false;

        if(filtersActive[5])
        {
            filterList("east",false);
            lookUnSelected(eastButton);
            filtersActive[5] = false;
            if(!(filtersActive[1]||filtersActive[2]||filtersActive[3]||filtersActive[4]||filtersActive[5]))
                allFilter();
        }
        else
        {
            filterList("east",true);
            lookSelected(eastButton);
            filtersActive[5] = true;
        }
    }

    public void showFilterTapped(View view)
    {
        if(filterHidden)
            showFilter();
        else
            hideFilter();
    }

    private void checkForFilter()
    {
        if(selectedFilters.contains("all"))
        {
            if(currentSearchText.equals(""))
            {
                setAdapter(apartmentList);
            }
            else
            {
                ArrayList<Apartment> filteredApartments = new ArrayList<Apartment>();
                for(Apartment apartment: apartmentList)
                {
                    if(apartment.getName().toLowerCase().contains(currentSearchText))
                    {
                        filteredApartments.add(apartment);
                    }
                }
                setAdapter(filteredApartments);
            }
        }
        else
        {
            filterList(null,false);
        }
    }

    private void setAdapter(ArrayList<Apartment> arr)
    {
        ApartmentAdapter adapter = new ApartmentAdapter(getApplicationContext(), 0, arr);
        listView.setAdapter(adapter);
    }

    public void goHome(View view)
    {
        finish();
    }
}