package com.example.housinguta;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class AdminAccountInfoActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_account_info);


        TextView account_info = findViewById(R.id.account_info);
        account_info.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view) {
                //Toast.makeText(getActivity(), "viewing account info", Toast.LENGTH_LONG).show();
                Intent intent = new Intent(view.getContext(), AccountInfoActivity.class);
                view.getContext().startActivity(intent);
            }
        });

        TextView change_names = findViewById(R.id.change_names);
        change_names.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view) {
                //Toast.makeText(getActivity(), "changing names", Toast.LENGTH_LONG).show();
                Intent intent = new Intent(view.getContext(), ChangeNamesActivity.class);
                view.getContext().startActivity(intent);
            }
        });
        TextView change_email = findViewById(R.id.change_email);
        change_email.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view)
            {
                //Toast.makeText(getActivity(), "changing email", Toast.LENGTH_LONG).show();
                Intent intent = new Intent(view.getContext(), ChangeEmailActivity.class);
                view.getContext().startActivity(intent);
            }
        });
        TextView change_password = findViewById(R.id.change_password);
        change_password.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view)
            {
                //Toast.makeText(getActivity(), "changing password", Toast.LENGTH_LONG).show();
                Intent intent = new Intent(view.getContext(), ChangePasswordActivity.class);
                view.getContext().startActivity(intent);
            }
        });

        Button btnMainMenu=findViewById(R.id.btnHomeMenu);
        btnMainMenu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                switchToHome();
            }
        });
    }
    private void switchToHome()
    {
            Intent intent = new Intent(this, AdminHomeActivity.class);
            startActivity(intent);
            finish();
    }
}
