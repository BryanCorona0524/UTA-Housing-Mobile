package com.example.housinguta;

        import androidx.appcompat.app.AppCompatActivity;

        import android.content.Intent;
        import android.graphics.Bitmap;
        import android.graphics.BitmapFactory;
        import android.net.Uri;
        import android.os.Bundle;
        import android.text.method.LinkMovementMethod;
        import android.view.View;
        import android.widget.Button;
        import android.widget.ImageView;
        import android.widget.TextView;

public class GenHallActivity extends AppCompatActivity {
    TextView prvSutTv;
    TextView douSutTv;
    TextView phoneTv;
    TextView addressTv;
    TextView hallTv;
    ImageView housingImage;
    TextView model;
    TextView back;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_gen_hall);
        prvSutTv = findViewById(R.id.prvSutTv);
        douSutTv = findViewById(R.id.DouSutTv);
        phoneTv = findViewById(R.id.PhoneTv);
        addressTv = findViewById(R.id.AddressTv);
        hallTv = findViewById(R.id.hallTv);
        housingImage = findViewById(R.id.housingImage);
        model = findViewById(R.id.modelText);
        back = findViewById(R.id.backButton);

        prvSutTv.append(getIntent().getStringExtra("price1"));
        douSutTv.append(getIntent().getStringExtra("price2"));
        phoneTv.append(getIntent().getStringExtra("phone"));
        addressTv.append(getIntent().getStringExtra("address"));
        hallTv.append(getIntent().getStringExtra("housing"));


        Bitmap bitmap = BitmapFactory.decodeByteArray(
                getIntent().getByteArrayExtra("byteArray"), 0, getIntent().getByteArrayExtra("byteArray").length);
        housingImage.setImageBitmap(bitmap);
    }
    public void gotoLink(View v) {
        Uri uri = Uri.parse(getIntent().getStringExtra("model"));
        Intent intent = new Intent(Intent.ACTION_VIEW, uri);
        startActivity(intent);
    }
    public void gotoList(View v){
        Intent intent = new Intent(this,OnCampusHousing.class);
        startActivity(intent);
    }
}