package com.example.housinguta;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.google.android.material.navigation.NavigationView;
import com.google.firebase.auth.FirebaseAuth;

public class HomeMenu extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener {

    private DrawerLayout drawer;
    //Button btnOnCampusApply;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home_menu);

        Toolbar toolbar=findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        drawer = findViewById(R.id.drawer_layout);
        NavigationView navigationView=findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);

        ActionBarDrawerToggle toggle= new ActionBarDrawerToggle(this,drawer,toolbar,R.string.navigation_drawer_open,R.string.navigation_drawer_close);
        drawer.addDrawerListener(toggle);
        toggle.syncState();

        if(savedInstanceState==null) {
            getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container, new MainMenuFragment()).commit();
            navigationView.setCheckedItem(R.id.main_menu);
        }
        /*
        Button btnOnCampusApply = findViewById(R.id.btnOnCampusApply);
        btnOnCampusApply.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view) {
                switchToOCA();
            }
        });*/
    }

    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId())
        {
            case R.id.main_menu:
                getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container,new MainMenuFragment()).commit();
                break;
            case R.id.change_account_details:
                getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container,new AccountInfoFragment()).commit();
                break;
            case R.id.messaging_section:
                //Toast.makeText(this,"checking messages",Toast.LENGTH_SHORT).show();
                getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container,new MessagesFragment()).commit();
                break;
            case R.id.view_applications:
                getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container,new ViewApplicationsFragment()).commit();
                break;
            case R.id.logout:
                //Toast.makeText(this,"logging out",Toast.LENGTH_SHORT).show();
                logoutUser();
                break;
        }

        drawer.closeDrawer(GravityCompat.START);

        return true;
    }

    @Override
    public void onBackPressed()
    {
        if(drawer.isDrawerOpen(GravityCompat.START))
        {
            drawer.closeDrawer(GravityCompat.START);
        }
        else
        {
            super.onBackPressed();
        }
    }

    private void logoutUser()
    {
        FirebaseAuth.getInstance().signOut();
        Intent intent = new Intent(this, LoginActivity.class);
        startActivity(intent);
        finish();
    }
    /*
    private void switchToOCA()
    {
        Intent intent = new Intent(this, OCApplicationActivity.class);
        startActivity(intent);
        finish();
    }*/
}