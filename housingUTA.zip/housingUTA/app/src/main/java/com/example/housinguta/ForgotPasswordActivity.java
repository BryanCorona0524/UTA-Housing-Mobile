package com.example.housinguta;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Patterns;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

public class ForgotPasswordActivity extends AppCompatActivity
{
    TextView textViewSwitchToLogin;
    EditText etLoginEmail;
    Button btnResetPassword;
    FirebaseAuth auth;
    FirebaseUser currentUser;
    String email;
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_forgot_password);

        etLoginEmail = findViewById(R.id.etLoginEmail);
        btnResetPassword = findViewById(R.id.btnResetPassword);
        textViewSwitchToLogin=findViewById(R.id.tvSwitchToLogin);
        auth = FirebaseAuth.getInstance();
        currentUser = auth.getCurrentUser();

        btnResetPassword.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view)
            {
                resetPassword();
            }
        });

        textViewSwitchToLogin.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view)
            {
                switchToLogin();
            }
        });

    }

    private void resetPassword()
    {
        //FirebaseAuth auth=FirebaseAuth.getInstance();
        email = etLoginEmail.getText().toString().trim();

        //checks if the email field is empty
        if (email.isEmpty()) {
            Toast.makeText(this, "Please enter an email", Toast.LENGTH_LONG).show();
            return;
        }
        //checks if the email is in the right format
        if (!Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            Toast.makeText(this, "Please enter a valid email", Toast.LENGTH_LONG).show();
            return;
        }

        if (currentUser == null)
        {
            auth.sendPasswordResetEmail(email).addOnCompleteListener(new OnCompleteListener<Void>()
            {
                @Override
                public void onComplete(@NonNull Task<Void> task)
                {
                    if(task.isSuccessful())
                    {
                        System.out.println("Email= *"+email+"*");
                        Toast.makeText(ForgotPasswordActivity.this,"Check your email to reset password", Toast.LENGTH_LONG).show();
                    }
                    else
                    {
                        Toast.makeText(ForgotPasswordActivity.this,"Something went wrong. Please try again", Toast.LENGTH_LONG).show();
                    }
                }

            }).addOnFailureListener(new OnFailureListener() {
                @Override
                public void onFailure(@NonNull Exception e) {
                    Toast.makeText(ForgotPasswordActivity.this,e.getMessage(), Toast.LENGTH_LONG).show();
                }
            });
        }
        else
        {
            Toast.makeText(ForgotPasswordActivity.this,"????", Toast.LENGTH_LONG).show();
        }
    }

    private void switchToLogin() {
        Intent intent = new Intent(this, LoginActivity.class);
        startActivity(intent);
        finish();
    }
}