package com.example.housinguta;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.util.Patterns;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthCredential;
import com.google.firebase.auth.EmailAuthProvider;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class ChangePasswordActivity extends AppCompatActivity {

    FirebaseUser user;
    Button btnMainMenu,btnUpdatePassword,btnAuthenticate;
    Boolean authenticated;
    String password,isAdmin;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_change_password);

        user = FirebaseAuth.getInstance().getCurrentUser();
        authenticated=false;

        btnMainMenu=findViewById(R.id.btnHomeMenu);
        btnMainMenu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                switchToHome();
            }
        });

        btnAuthenticate = findViewById(R.id.btnauthenticate);
        btnAuthenticate.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view) {
                authenticateUser();
            }
        });

        btnUpdatePassword = findViewById(R.id.btnUpdate);
        btnUpdatePassword.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view) {
                changePassword();
            }
        });


        FirebaseDatabase database = FirebaseDatabase.getInstance();
        DatabaseReference reference = database.getReference("users").child(user.getUid());
        reference.addValueEventListener(new ValueEventListener()
        {
            @SuppressLint("SetTextI18n")//this is what was changed!!!!!
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot)
            {
                User user = snapshot.getValue(User.class);
                if (user != null) {
                    isAdmin=(user.isAdmin);
                }
            }
            @Override
            public void onCancelled(@NonNull DatabaseError error)
            {
            }
        });
    }

    private void authenticateUser() {
        EditText etLoginEmail = findViewById(R.id.etEmail);
        EditText etLoginPassword = findViewById(R.id.etPassword);

        String email = etLoginEmail.getText().toString();
        password = etLoginPassword.getText().toString();

        //checks if the fields are empty
        if (email.isEmpty() || password.isEmpty()) {
            Toast.makeText(this, "Please fill all fields", Toast.LENGTH_LONG).show();
            return;
        }
        //checks if the email is in the right format
        if (!Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            Toast.makeText(this, "Please enter a valid email", Toast.LENGTH_LONG).show();
            return;
        }
        //checks if the password is at least 6 chars long
        if (password.length() < 6) {
            Toast.makeText(this, "Please enter a longer password", Toast.LENGTH_LONG).show();
            return;
        }

        //user = FirebaseAuth.getInstance().getCurrentUser();
        // Get auth credentials from the user for re-authentication. The example below shows
        // email and password credentials but there are multiple possible providers,
        // such as GoogleAuthProvider or FacebookAuthProvider.
        AuthCredential credential = EmailAuthProvider
                .getCredential(email, password);

        // Prompt the user to re-provide their sign-in credentials
        user.reauthenticate(credential)
                .addOnCompleteListener(new OnCompleteListener<Void>() {
                    @Override
                    public void onComplete(@NonNull Task<Void> task) {
                        Toast.makeText(ChangePasswordActivity.this,"enter new password",Toast.LENGTH_SHORT).show();
                        authenticated=true;
                    }
                });
    }
    private void changePassword() {
        EditText etNEWPassword = findViewById(R.id.etNEWpassword);
        String newPassword = etNEWPassword.getText().toString().trim();

        EditText etconfirmNEWPassword = findViewById(R.id.etconfirmNEWpassword);
        String confirmNewPassword = etconfirmNEWPassword.getText().toString().trim();

        //checks if the user has authenticated their account first
        if(!authenticated)
        {
            Toast.makeText(this, "Please authenticate first", Toast.LENGTH_LONG).show();
            return;
        }
        //check if they are empty
        if (newPassword.isEmpty() || confirmNewPassword.isEmpty()) {
            Toast.makeText(this, "Please fill all fields", Toast.LENGTH_LONG).show();
            return;
        }
        //checks if the password  is at least 6 chars long
        if (newPassword.length() < 6 || confirmNewPassword.length()<6) {
            Toast.makeText(this, "Please enter a longer password", Toast.LENGTH_LONG).show();
            return;
        }
        //checks if the passwords are the same
        if (password.equals(newPassword)) {
            Toast.makeText(this, "This is your current password", Toast.LENGTH_LONG).show();
            return;
        }
        //check if they are the same
        if(!newPassword.equals(confirmNewPassword)) {
            Toast.makeText(this, "Passwords are not the same", Toast.LENGTH_LONG).show();
            return;
        }
        user.updatePassword(newPassword)
                .addOnCompleteListener(new OnCompleteListener<Void>() {
                    @Override
                    public void onComplete(@NonNull Task<Void> task) {
                        if (task.isSuccessful())
                        {
                            Toast.makeText(ChangePasswordActivity.this, "password changed!", Toast.LENGTH_LONG).show();
                            //if 0 then user is not admin
                            if(isAdmin.equals("0"))
                            {
                                switchToHome();
                            }
                            //else user is admin
                            else {
                                switchToAdminHome();
                            }
                        }
                    }
                });
    }

    private void switchToHome()
    {
        if(isAdmin.equals("0"))
        {

            Intent intent = new Intent(this, HomeMenu.class);
            startActivity(intent);
            finish();
        }
        else
        {
            Intent intent = new Intent(this, AdminAccountInfoActivity.class);
            startActivity(intent);
            finish();
        }
    }
    private void switchToAdminHome()
    {
        Intent intent = new Intent(this, AdminHomeActivity.class);
        startActivity(intent);
        finish();
    }
}