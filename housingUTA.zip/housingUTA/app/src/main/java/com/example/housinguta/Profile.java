package com.example.housinguta;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.DrawableRes;
import androidx.appcompat.app.AppCompatActivity;

public class Profile extends AppCompatActivity
{
    Button homeButton, websiteButton;
    ImageView img;
    TextView nameTv, priceTv, addressTv, phoneTv, emailTv;
    String websiteURL, phoneNumFormatted;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.apartment_profile);

        homeButton    = findViewById(R.id.backButton);
        websiteButton = findViewById(R.id.btnWeb);
        img           = (ImageView) findViewById(R.id.imageView);
        nameTv        = findViewById(R.id.nameText);
        priceTv       = findViewById(R.id.priceText);
        addressTv     = findViewById(R.id.addressText);
        phoneTv       = findViewById(R.id.phoneText);
        emailTv       = findViewById(R.id.emailText);

        websiteURL        = getIntent().getStringExtra("website");
        phoneNumFormatted = getIntent().getStringExtra("phone");

        nameTv.setText(getIntent().getStringExtra("name"));
        priceTv.setText(getIntent().getStringExtra("price"));
        if(getIntent().getStringExtra("price").contains("n/a"))
            priceTv.setVisibility(View.GONE);
        else
            priceTv.setVisibility(View.VISIBLE);
        addressTv.setText(getIntent().getStringExtra("address"));
        if(phoneNumFormatted.contains("n/a"))
            phoneTv.setText("Phone: " + phoneNumFormatted);
        else
            phoneTv.setText("Phone: +" + phoneNumFormatted.substring(0,1) + " " + phoneNumFormatted.substring(1,4) + "-" + phoneNumFormatted.substring(4,7) + "-" + phoneNumFormatted.substring(7,11));
        emailTv.setText("Email:  " + getIntent().getStringExtra("email"));

        websiteButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                gotoUrl("https://" + websiteURL);
            }
        });

        switch(Integer.parseInt(getIntent().getStringExtra("image")))
        {
            case 1:
                img.setImageResource(R.drawable.oc1);
                break;
            case 2:
                img.setImageResource(R.drawable.oc2);
                break;
            case 3:
                img.setImageResource(R.drawable.oc3);
                break;
            case 4:
                img.setImageResource(R.drawable.oc4);
                break;
            case 5:
                img.setImageResource(R.drawable.oc5);
                break;
            case 6:
                img.setImageResource(R.drawable.oc6);
                break;
            case 7:
                img.setImageResource(R.drawable.oc7);
                break;
            case 8:
                img.setImageResource(R.drawable.oc8);
                break;
            case 9:
                img.setImageResource(R.drawable.oc9);
                break;
            case 10:
                img.setImageResource(R.drawable.oc10);
                break;
            case 11:
                img.setImageResource(R.drawable.oc11);
                break;
            case 12:
                img.setImageResource(R.drawable.oc12);
                break;
            case 13:
                img.setImageResource(R.drawable.oc13);
                break;
            case 14:
                img.setImageResource(R.drawable.oc14);
                break;
            case 15:
                img.setImageResource(R.drawable.oc15);
                break;
            case 16:
                img.setImageResource(R.drawable.oc16);
                break;
            case 17:
                img.setImageResource(R.drawable.oc17);
                break;
            case 18:
                img.setImageResource(R.drawable.oc18);
                break;
            case 19:
                img.setImageResource(R.drawable.oc19);
                break;
            case 20:
                img.setImageResource(R.drawable.oc20);
                break;
            case 21:
                img.setImageResource(R.drawable.oc21);
                break;
            case 22:
                img.setImageResource(R.drawable.oc22);
                break;
            case 23:
                img.setImageResource(R.drawable.oc23);
                break;
            case 24:
                img.setImageResource(R.drawable.oc24);
                break;
            case 25:
                img.setImageResource(R.drawable.oc25);
                break;
            case 26:
                img.setImageResource(R.drawable.oc26);
                break;
            case 27:
                img.setImageResource(R.drawable.oc27);
                break;
            case 28:
                img.setImageResource(R.drawable.oc28);
            default: break;
        }
    }

    private void gotoUrl(String s)
    {
        Uri uri = Uri.parse(s);
        startActivity(new Intent(Intent.ACTION_VIEW,uri));
    }

    public void goHome(View view)
    {
        finish();
    }
}
