package com.example.housinguta;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;

import java.io.ByteArrayOutputStream;
import java.util.ArrayList;
import java.util.Arrays;

public class OnCampusHousing extends AppCompatActivity implements AdapterView.OnItemClickListener{

    ListView ochList;
    String[] och ={"Arlington Hall", "KC Hall", "Vandergriff Hall", "West Hall",
            "Arbor Oaks", "The Heights on Pecan", "Meadow Run", "The Lofts",
            "Timber Brook", "University Village", "Centennial Court"};
    String[] adress = {"600 Spaniolo Dr, Arlington, TX 76010","901 S Oak St., Arlington, Texas 76010",
            "587 Spaniolo Dr, Arlington, Texas 76010","916 UTA Boulevard, Arlington, TX 76013","1000 - 1008 Greek Row Dr., Arlington, Texas",
            "1225 S. Pecan St, Arlington, Texas 76010","409 - 607 Summit Dr., Arlington, Texas","500 S. Center St, Arlington TX 76010",
            "400 - 410 Kerby St., Arlington, Texas","900 - 914 Greek Row Dr., Arlington, Texas","700 West Mitchell Circle, Arlington, Texas"};
    String[] phone  = {"(817) 272-7951","817-272-9577","817-272-6600","(817) 272-6951","N/A","N/A","N/A","N/A","N/A","N/A","817-789-4764"};
    String[] price1 = {"6,470","6470","N/A","N/A","Low:$979\n   High:$1,382","Low:$N/A\n   High:$N/A","Low:$979\n   High:$1,382",
            "Low:$1,015\n   High:$N/A","Low:$N/A\n   High:$N/A","Low:$783\n   High:$805","Low:$885\n   High:$1,057"};
    String[] price2 = {"5,413","5,413","5,695","5,951","Low:$N/A\n   High:$N/A","Low:$686\n   High:$910","Low:$N/A\n   High:$N/A",
            "Low:$721\n   High:N/A","Low:$365\n   High:$509","Low:$N/A\n   High:$N/A","Low:$522\n   High:$618"};
    String[] model = {"https://my.matterport.com/show/?m=typK5dzRhgf","https://my.matterport.com/show/?m=oc1vdzkYnAm","https://my.matterport.com/show/?m=SWpW6tindBV",
            "https://my.matterport.com/show/?m=fu6majU4bPB&cta=0","https://my.matterport.com/show/?m=PGefApP7JiT","https://my.matterport.com/show/?m=xaqnizGkVMR",
            "https://my.matterport.com/show/?m=iRCcd3p7US3","https://my.matterport.com/show/?m=v8urE4r4Cxb","https://my.matterport.com/show/?m=WbgUg9FjdiM",
            "https://my.matterport.com/show/?m=ZorohZm1QJp","N/A"};
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_och);

        ochList = findViewById(R.id.ochList);
        ArrayAdapter <String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, och);
        ochList.setAdapter(adapter);
        ochList.setOnItemClickListener(this);


        Button btnMainMenu=findViewById(R.id.btnHomeMenu);
        btnMainMenu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                switchToHome();
            }
        });
    }

    @Override
    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
        String selected = parent.getItemAtPosition(position).toString();
        ArrayList<String> data;
        Intent intent;
        Bitmap bitmap;
        ByteArrayOutputStream bs = new ByteArrayOutputStream();
        data = new ArrayList<String>(Arrays.asList(och[position],price1[position],price2[position],
                phone[position],adress[position],model[position]));
        if(position ==0){
            intent = new Intent(this,GenHallActivity.class);
            bitmap = BitmapFactory.decodeResource
                    (getResources(), R.drawable.arlingtonhall);
            bitmap.compress(Bitmap.CompressFormat.JPEG, 50, bs);
        }else if(position ==1) {
            intent = new Intent(this,GenHallActivity.class);
            bitmap = BitmapFactory.decodeResource
                    (getResources(), R.drawable.kchall); // your bitmap
            bitmap.compress(Bitmap.CompressFormat.JPEG, 50, bs);
        }else if(position ==2) {
            intent = new Intent(this,GenHallActivity.class);
            bitmap = BitmapFactory.decodeResource
                    (getResources(), R.drawable.vhall); // your bitmap
            bitmap.compress(Bitmap.CompressFormat.JPEG, 50, bs);
        }else if(position ==3){
            intent = new Intent(this,GenHallActivity.class);
            bitmap = BitmapFactory.decodeResource
                    (getResources(), R.drawable.westhall); // your bitmap
            bitmap.compress(Bitmap.CompressFormat.JPEG, 50, bs);
        }else if(position ==4){
            intent = new Intent(this,GenAptmActivity.class);
            bitmap = BitmapFactory.decodeResource
                    (getResources(), R.drawable.arboroaks); // your bitmap
            bitmap.compress(Bitmap.CompressFormat.JPEG, 50, bs);
        }else if(position ==5){
            intent = new Intent(this,GenAptmActivity.class);
            bitmap = BitmapFactory.decodeResource
                    (getResources(), R.drawable.theheights); // your bitmap
            bitmap.compress(Bitmap.CompressFormat.JPEG, 50, bs);
        }else if(position ==6){
            intent = new Intent(this,GenAptmActivity.class);
            bitmap = BitmapFactory.decodeResource
                    (getResources(), R.drawable.meadowrun); // your bitmap
            bitmap.compress(Bitmap.CompressFormat.JPEG, 50, bs);
        }else if(position ==7){
            intent = new Intent(this,GenAptmActivity.class);
            bitmap = BitmapFactory.decodeResource
                    (getResources(), R.drawable.thelofts); // your bitmap
            bitmap.compress(Bitmap.CompressFormat.JPEG, 50, bs);
        }else if(position ==8){
            intent = new Intent(this,GenAptmActivity.class);
            bitmap = BitmapFactory.decodeResource
                    (getResources(), R.drawable.timberbrook); // your bitmap
            bitmap.compress(Bitmap.CompressFormat.JPEG, 50, bs);
        }else if(position ==9){
            intent = new Intent(this,GenAptmActivity.class);
            bitmap = BitmapFactory.decodeResource
                    (getResources(), R.drawable.univillage); // your bitmap
            bitmap.compress(Bitmap.CompressFormat.JPEG, 50, bs);
        }else{
            intent = new Intent(this,GenAptmActivity.class);
            bitmap = BitmapFactory.decodeResource
                    (getResources(), R.drawable.centennialcourt); // your bitmap
            bitmap.compress(Bitmap.CompressFormat.JPEG, 50, bs);
        }
        intent.putExtra("byteArray", bs.toByteArray());
        setValues(data,intent);

        startActivity(intent);

        //Toast.makeText(getApplicationContext(),"Clicked "+selected,Toast.LENGTH_SHORT).show();
    }
    private void setValues(ArrayList<String> data, Intent intent){
        intent.putExtra("housing",data.get(0));
        intent.putExtra("price1",data.get(1));
        intent.putExtra("price2",data.get(2));
        intent.putExtra("phone",data.get(3));
        intent.putExtra("address",data.get(4));
        intent.putExtra("model",data.get(5));

    }


    private void switchToHome()
    {
            Intent intent = new Intent(this, HomeMenu.class);
            startActivity(intent);
            finish();
    }

}