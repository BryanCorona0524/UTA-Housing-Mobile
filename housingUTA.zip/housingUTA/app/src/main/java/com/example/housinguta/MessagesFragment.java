package com.example.housinguta;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

public class MessagesFragment extends Fragment
{
    View view;
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState)
    {

        view=inflater.inflate(R.layout.fragment_messages,container,false);
        TextView account_info = view.findViewById(R.id.compose_message);
        account_info.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view) {
                Toast.makeText(getActivity(), "composing message", Toast.LENGTH_LONG).show();
                //Intent intent = new Intent(view.getContext(), AccountInfoActivity.class);
                //view.getContext().startActivity(intent);
            }
        });

        TextView change_names = view.findViewById(R.id.view_messages);
        change_names.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view) {
                Toast.makeText(getActivity(), "viewing messages", Toast.LENGTH_LONG).show();
                //Intent intent = new Intent(view.getContext(), ChangeNamesActivity.class);
                //view.getContext().startActivity(intent);
            }
        });
        return view;
    }
}
