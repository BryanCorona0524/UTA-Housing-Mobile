package com.example.housinguta;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.util.Patterns;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.Objects;

public class ChangeNamesActivity extends AppCompatActivity {

    FirebaseUser currentUser;
    Button btnMainMenu,btnUpdateName;
    String email,isAdmin;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_change_names);

        currentUser = FirebaseAuth.getInstance().getCurrentUser();

        btnMainMenu=findViewById(R.id.btnHomeMenu);
        btnMainMenu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                switchToHome();
            }
        });

        btnUpdateName = findViewById(R.id.btnUpdate);
        btnUpdateName.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view) {
                changeNames();
            }
        });

        //get the users current email from the database
        FirebaseDatabase database = FirebaseDatabase.getInstance();
        DatabaseReference reference = database.getReference("users").child(currentUser.getUid());
        reference.addValueEventListener(new ValueEventListener()
        {
            @SuppressLint("SetTextI18n")//this is what was changed!!!!!
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot)
            {
                User user = snapshot.getValue(User.class);
                if (user != null) {
                    email=(user.email);
                    isAdmin=(user.isAdmin);
                }
            }
            @Override
            public void onCancelled(@NonNull DatabaseError error)
            {
            }
        });
    }
    private void changeNames() {
        EditText etFirstname = findViewById(R.id.etFirstname);
        String firstname = etFirstname.getText().toString().trim();

        EditText etLastname = findViewById(R.id.etLastname);
        String lastname = etLastname.getText().toString().trim();
        //check if they are empty
        if (firstname.isEmpty() || lastname.isEmpty()) {
            Toast.makeText(this, "Please fill all fields", Toast.LENGTH_LONG).show();
            return;
        }
        User user = new User(firstname, lastname, email, isAdmin);
        FirebaseDatabase.getInstance().getReference("users")
                .child(Objects.requireNonNull(FirebaseAuth.getInstance().getCurrentUser()).getUid())
                .setValue(user).addOnCompleteListener(new OnCompleteListener<Void>()
                {
                    @Override
                    public void onComplete(@NonNull Task<Void> task)
                    {
                        Toast.makeText(ChangeNamesActivity.this, "names updated!", Toast.LENGTH_LONG).show();
                        //if 0 then user is not admin
                        if(isAdmin.equals("0"))
                        {
                            switchToAccountInfo();
                        }
                        //else user is admin
                        else {
                            switchToAdminHome();
                        }
                    }
                });
    }

    private void switchToAccountInfo()
    {
        Intent intent = new Intent(this, AccountInfoActivity.class);
        startActivity(intent);
        finish();
    }
    private void switchToAdminHome()
    {
        Intent intent = new Intent(this, AdminHomeActivity.class);
        startActivity(intent);
        finish();
    }
    private void switchToHome()
    {
        if(isAdmin.equals("0"))
        {

            Intent intent = new Intent(this, HomeMenu.class);
            startActivity(intent);
            finish();
        }
        else {
            Intent intent = new Intent(this, AdminAccountInfoActivity.class);
            startActivity(intent);
            finish();
        }
    }
}