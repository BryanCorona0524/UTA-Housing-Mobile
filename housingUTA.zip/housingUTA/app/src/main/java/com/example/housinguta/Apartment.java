package com.example.housinguta;

public class Apartment
{
    private String name;
    private String region;
    private String address;
    private String phone;
    private String email;
    private String website;
    private String price;
    private String image;

    public Apartment(String[] arr)
    {
        this.name    = arr[0];
        this.region  = arr[1];
        this.address = arr[2];
        this.website = arr[3];
        this.phone   = arr[4];
        this.email   = arr[5];
        this.price   = arr[6];
        this.image   = arr[7];
    }

    public String getName()    { return this.name; }
    public String getRegion()  { return this.region; }
    public String getAddress() { return this.address; }
    public String getPhone()   { return this.phone; }
    public String getEmail()   { return this.email; }
    public String getWebsite() { return this.website; }
    public String getPrice()   { return this.price; }
    public String getImage()   { return this.image; }
}
