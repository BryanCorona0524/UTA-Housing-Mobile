package com.example.housinguta;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

public class ViewApplicationsFragment extends Fragment
{
    View view;
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState)
    {

        view=inflater.inflate(R.layout.fragment_view_applications,container,false);
        TextView account_info = view.findViewById(R.id.on_campus_app);
        account_info.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view) {
                Toast.makeText(getActivity(), "viewing on campus app", Toast.LENGTH_LONG).show();
                //Intent intent = new Intent(view.getContext(), AccountInfoActivity.class);
                //view.getContext().startActivity(intent);
            }
        });

        TextView change_names = view.findViewById(R.id.tour_application);
        change_names.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view) {
                Toast.makeText(getActivity(), "viewing tour app", Toast.LENGTH_LONG).show();
                //Intent intent = new Intent(view.getContext(), ChangeNamesActivity.class);
                //view.getContext().startActivity(intent);
            }
        });
        return view;
    }
}
