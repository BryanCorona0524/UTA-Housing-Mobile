package com.example.housinguta;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.app.Dialog;
import android.content.Intent;
import android.os.Bundle;
import android.util.Patterns;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import android.widget.ArrayAdapter;
import android.widget.Spinner;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.FirebaseDatabase;

import java.util.Objects;

public class OCApplicationActivity extends AppCompatActivity {

    public FirebaseUser user;
    Dialog dialog;
    public String uid;
    EditText etName;
    EditText etStudentID;
    EditText etDOB;
    EditText etGender;
    EditText etPhone;
    EditText etEmail;
    EditText etEmergencyName;
    EditText etEmergencyPhone;
    EditText etEmergencyEmail;
    CheckBox cbCaronCampus;
    CheckBox cbSpecialHousing;
    CheckBox cbchp62reg;
    EditText etRoomPreference1;
    EditText etRoomPreference2;
    CheckBox cbWaitlist;
    CheckBox cbAgreement;
    //TextView fullName;
    EditText etSignature;
    //spinners
    Spinner spinner;
    Spinner spinner2;

    @SuppressLint("UseCompatLoadingForDrawables")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ocapplication_activity);

        // button for validating and submitting the application
        Button btnValidatePersonalDetails=findViewById(R.id.btnValidatePersonalDetails);
        btnValidatePersonalDetails.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view)
            {
                registerApplication();
            }
        });

        //dialog box for confirmation
        dialog=new Dialog(OCApplicationActivity.this);
        dialog.setContentView(R.layout.confirmation_message);
        dialog.getWindow().setBackgroundDrawable(getDrawable(R.drawable.confirmation_background));
        dialog.getWindow().setLayout(ViewGroup.LayoutParams.MATCH_PARENT,ViewGroup.LayoutParams.WRAP_CONTENT);
        dialog.setCancelable(false);
        dialog.getWindow().getAttributes().windowAnimations=R.style.animation;

        //button for confirmation dialog
        Button btn_ok = dialog.findViewById(R.id.btn_ok);
        btn_ok.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view)
            {
                switchToHome();
                dialog.dismiss();
            }
        });

        spinner=findViewById(R.id.spinner);
        spinner2=findViewById(R.id.spinner2);
        ArrayAdapter<CharSequence>adapter=ArrayAdapter.createFromResource(this, R.array.housing, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_item);
        spinner.setAdapter(adapter);
        spinner2.setAdapter(adapter);

        //button to go home
        Button btnMainMenu=findViewById(R.id.btnHomeMenu);
        btnMainMenu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                switchToHome();
            }
        });
    }

    private void registerApplication()
    {

        //spinner strings
        String pref1 = spinner.getSelectedItem().toString();
        String pref2 = spinner2.getSelectedItem().toString();
        user = FirebaseAuth.getInstance().getCurrentUser();
        if (user != null)
        {
            // User is signed in
            uid = user.getUid();
            //System.out.println("current users id"+uid);
        }
        etName = findViewById(R.id.etName);
        etStudentID = findViewById(R.id.etStudentID);
        etDOB = findViewById(R.id.etDOB);
        etGender = findViewById(R.id.etGender);
        etPhone = findViewById(R.id.etPhone);
        etEmail = findViewById(R.id.etEmail);
        etEmergencyName = findViewById(R.id.etEmergencyName);
        etEmergencyPhone = findViewById(R.id.etEmergencyPhone);
        etEmergencyEmail = findViewById(R.id.etEmergencyEmail);
        cbCaronCampus = findViewById(R.id.cbCaronCampus);
        cbSpecialHousing = findViewById(R.id.cbSpecialHousing);
        cbchp62reg = findViewById(R.id.cbChapter62reg);
        //etRoomPreference1 = findViewById(R.id.etRoomPreference1);
        //etRoomPreference2 = findViewById(R.id.etRoomPreference2);
        cbWaitlist = findViewById(R.id.cbWaitlist);
        cbAgreement = findViewById(R.id.cbAgreement);
        etSignature = findViewById(R.id.etSignature);

        String name = etName.getText().toString();
        String studentID = etStudentID.getText().toString();
        String dateofbirth = etDOB.getText().toString();
        String gender = etGender.getText().toString();
        String phone = etPhone.getText().toString();
        String email = etEmail.getText().toString();
        String emergency_contact_name = etEmergencyName.getText().toString();
        String emergency_contact_email = etEmergencyEmail.getText().toString();
        String emergency_contact_phone = etEmergencyPhone.getText().toString();
        boolean carOnCampus=false;
        boolean specialHousing=false;
        boolean chp62reg=false;
        //String preference_1 = etRoomPreference1.getText().toString();
        //String preference_2 = etRoomPreference2.getText().toString();
        boolean waitlist=false;
        boolean online;
        String signature = etSignature.getText().toString();

        //check if the items are empty
        if (name.isEmpty() || studentID.isEmpty() || dateofbirth.isEmpty() || gender.isEmpty() || phone.isEmpty() || emergency_contact_name.isEmpty() || emergency_contact_email.isEmpty() || emergency_contact_phone.isEmpty() || pref1.isEmpty() || pref2.isEmpty() || signature.isEmpty())
        {
            Toast.makeText(this, "Please fill all text boxes", Toast.LENGTH_LONG).show();
            return;
        }
        // check if pref1/pref2 are empty
        if(pref1.equals("Select Housing") || pref2.equals("Select Housing"))
        {
            Toast.makeText(this, "Please select your room preferences", Toast.LENGTH_LONG).show();
            return;
        }
        //check if pref1/pref2 are not the same
        if(pref1.equals(pref2))
        {
            Toast.makeText(this, "Please select different room preferences", Toast.LENGTH_LONG).show();
            return;
        }
        //checks if the email is in the right format
        if (!Patterns.EMAIL_ADDRESS.matcher(email).matches())
        {
            Toast.makeText(this, "Please enter a valid email", Toast.LENGTH_LONG).show();
            return;
        }
        //checks if the email is in the right format
        if (!Patterns.EMAIL_ADDRESS.matcher(emergency_contact_email).matches())
        {
            Toast.makeText(this, "Please enter a valid emergency contact email", Toast.LENGTH_LONG).show();
            return;
        }
        //checking for car on campus
        if (cbCaronCampus.isChecked())
        {
            carOnCampus=true;
        }
        //checking for special housing
        if (cbSpecialHousing.isChecked())
        {
            specialHousing=true;
        }
        //checking for chapter 62 registration
        if (cbchp62reg.isChecked())
        {
            chp62reg=true;
        }
        //checking for waitlist
        if (cbWaitlist.isChecked())
        {
            waitlist=true;
        }
        //check for online agreement
        if (cbAgreement.isChecked())
        {
            online=true;
        }
        else
        {
            Toast.makeText(this, "Please check online agreement", Toast.LENGTH_LONG).show();
            return;
        }

        OCApplication ocapplication = new OCApplication(name,studentID,dateofbirth,gender,phone,email,emergency_contact_name,emergency_contact_phone,emergency_contact_email,carOnCampus,specialHousing,chp62reg,pref1,pref2,waitlist,online,signature);
        FirebaseDatabase.getInstance().getReference("OnCampusApplications")
                .child(Objects.requireNonNull(FirebaseAuth.getInstance().getCurrentUser()).getUid())
                .setValue(ocapplication).addOnCompleteListener(new OnCompleteListener<Void>()
                {
                    @Override
                    public void onComplete(@NonNull Task<Void> task)
                    {
                        dialog.show();
                    }
                });
    }

    private void switchToHome()
    {
        Intent intent = new Intent(this, HomeMenu.class);
        startActivity(intent);
        finish();
    }
}