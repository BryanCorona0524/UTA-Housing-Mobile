package com.example.housinguta;

public class OCApplication
{
    //personal & contact details
    //public String uid;
    public String name;
    public String studentID;
    public String dateofbirth;
    public String gender;
    public String phone;
    public String email;
    public String emergency_contact_name;
    public String emergency_contact_phone;
    public String emergency_contact_email;
    public Boolean carOnCampus; //yes or no
    public Boolean specialHousing; // yes or no
    //chapter 62 registration
    public Boolean chp62reg;
    //room preferences
    public String preference_1;
    public String preference_2;
    public Boolean waitlist; //want to be in a waitlist? yes or no
    //online agreement
    public Boolean agreement; //acknowledge agreement
    //housing leasing signature
    public String signature;

    public OCApplication()
    {
    }

    public OCApplication (String name, String studentID, String gender, String dateofbirth, String phone, String email, String emergency_contact_name, String emergency_contact_phone, String emergency_contact_email, Boolean carOnCampus, Boolean specialHousing,Boolean chp62reg, String preference_1, String preference_2, Boolean waitlist, Boolean agreement, String signature)
    {
        //this.uid=uid;
        this.name=name;
        this.studentID=studentID;
        this.gender=gender;
        this.dateofbirth=dateofbirth;
        this.phone=phone;
        this.email=email;
        this.emergency_contact_name=emergency_contact_name;
        this.emergency_contact_phone=emergency_contact_phone;
        this.emergency_contact_email=emergency_contact_email;
        this.carOnCampus=carOnCampus;
        this.specialHousing=specialHousing;
        this.chp62reg=chp62reg;
        this.preference_1=preference_1;
        this.preference_2=preference_2;
        this.waitlist=waitlist;
        this.agreement=agreement;
        this.signature=signature;
    }
}